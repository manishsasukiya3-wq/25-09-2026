package com.example.data.local

import android.content.Context
import android.content.SharedPreferences
import com.example.data.model.User
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID

class SessionManager(context: Context) {
    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private val _currentUser = MutableStateFlow(loadUser())
    val currentUser: StateFlow<User?> = _currentUser.asStateFlow()

    private val _supabaseConfig = MutableStateFlow(loadSupabaseConfig())
    val supabaseConfig: StateFlow<Pair<String, String>> = _supabaseConfig.asStateFlow()

    fun getDeviceId(): String {
        var id = prefs.getString(KEY_DEVICE_ID, null)
        if (id.isNullOrBlank()) {
            id = UUID.randomUUID().toString()
            prefs.edit().putString(KEY_DEVICE_ID, id).apply()
        }
        return id
    }

    fun saveUser(user: User) {
        prefs.edit().apply {
            putLong(KEY_USER_ID, user.id ?: -1L)
            putString(KEY_USER_NAME, user.name)
            putString(KEY_USER_MOBILE, user.mobileNumber)
            putString(KEY_USER_ROLE, user.role)
            putString(KEY_SAVED_DEVICE_ID, user.deviceId ?: getDeviceId())
            putBoolean(KEY_IS_SUPER_ADMIN, user.isSuperAdminUser)
            apply()
        }
        _currentUser.value = user
    }

    fun clearSession() {
        prefs.edit().apply {
            remove(KEY_USER_ID)
            remove(KEY_USER_NAME)
            remove(KEY_USER_MOBILE)
            remove(KEY_USER_ROLE)
            remove(KEY_SAVED_DEVICE_ID)
            remove(KEY_IS_SUPER_ADMIN)
            apply()
        }
        _currentUser.value = null
    }

    fun getUser(): User? = _currentUser.value

    fun isLoggedIn(): Boolean = _currentUser.value != null

    fun saveSupabaseConfig(url: String, anonKey: String) {
        val cleanUrl = url.trim().trimEnd('/')
        val cleanKey = anonKey.trim()
        prefs.edit().apply {
            putString(KEY_SUPABASE_URL, cleanUrl)
            putString(KEY_SUPABASE_ANON_KEY, cleanKey)
            apply()
        }
        _supabaseConfig.value = Pair(cleanUrl, cleanKey)
    }

    fun getSupabaseConfig(): Pair<String, String> = _supabaseConfig.value

    private fun loadUser(): User? {
        val id = prefs.getLong(KEY_USER_ID, -1L)
        val name = prefs.getString(KEY_USER_NAME, null)
        val mobile = prefs.getString(KEY_USER_MOBILE, null)
        val role = prefs.getString(KEY_USER_ROLE, "student") ?: "student"
        val deviceId = prefs.getString(KEY_SAVED_DEVICE_ID, null)
        val isSuperAdmin = prefs.getBoolean(KEY_IS_SUPER_ADMIN, false)

        return if (mobile != null) {
            User(
                id = if (id >= 0) id else null,
                name = name,
                mobileNumber = mobile,
                password = null,
                role = role,
                deviceId = deviceId,
                isSuperAdmin = isSuperAdmin
            )
        } else {
            null
        }
    }

    private fun loadSupabaseConfig(): Pair<String, String> {
        val savedUrl = prefs.getString(KEY_SUPABASE_URL, DEFAULT_SUPABASE_URL) ?: DEFAULT_SUPABASE_URL
        val savedKey = prefs.getString(KEY_SUPABASE_ANON_KEY, DEFAULT_SUPABASE_ANON_KEY) ?: DEFAULT_SUPABASE_ANON_KEY
        return Pair(savedUrl.ifBlank { DEFAULT_SUPABASE_URL }, savedKey.ifBlank { DEFAULT_SUPABASE_ANON_KEY })
    }

    companion object {
        private const val PREFS_NAME = "test_mitra_session_prefs"
        private const val KEY_USER_ID = "user_id"
        private const val KEY_USER_NAME = "user_name"
        private const val KEY_USER_MOBILE = "user_mobile"
        private const val KEY_USER_ROLE = "user_role"
        private const val KEY_IS_SUPER_ADMIN = "is_super_admin"
        private const val KEY_DEVICE_ID = "app_device_uuid"
        private const val KEY_SAVED_DEVICE_ID = "saved_device_id"
        private const val KEY_SUPABASE_URL = "supabase_url"
        private const val KEY_SUPABASE_ANON_KEY = "supabase_anon_key"

        // Pre-configured Supabase Project Credentials
        const val DEFAULT_SUPABASE_URL = "https://vyxcerbdrjjphhqoksup.supabase.co"
        const val DEFAULT_SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZ5eGNlcmJkcmpqcGhocW9rc3VwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODY4NDk3NjEsImV4cCI6MjEwMjQyNTc2MX0.OHDfLOryTSMSYKd1iBqbblvTFFPg8UED_kb1W0-NOwU"
        const val BACKUP_SUPABASE_ANON_KEY = "sb_publishable_kZ4HFanq__cSA5yrrhXT1w_yi9lchOL"
    }
}
